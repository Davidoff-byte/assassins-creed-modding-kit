# Hidden Dagger — Assassin's Creed Rogue

**Short description:** Hides Shay's off-hand dagger so the sword set looks like
a single sword.

AC Rogue equips Shay with "sword and dagger" sets. This mod turns off the
visibility flags on the off-hand weapon entity for every sword set, so the
dagger is never drawn. The sword, its stats and the animations are untouched.

Version 1.0.

## Features

- Hides the off-hand dagger on all sword sets.
- Nothing else is changed — the sword and moveset stay as they are.
- Pairs with the **One-Handed Sword** mod (which changes the moveset).

## Requirements

- Assassin's Creed Rogue (PC).
- **Python 3** — only to run the installer. No other tools.
- The game **closed** (it locks `DataPC.forge`).

## Install

1. Quit Rogue completely.
2. Double-click **`Install.bat`**.
3. Launch the game and start a fight — the left hand is empty.

The installer looks in the standard Steam paths. If your game is somewhere
else, pass the file:

```
Install.bat "D:\path\to\Assassin's Creed Rogue\DataPC.forge"
```

## Uninstall

The installer saves the original as `DataPC.forge.bak_dagger` next to the game.
Copy that back over `DataPC.forge` to undo.

## Notes

- Only edits your own copy of `DataPC.forge` — no game files are shipped.
- A Steam "verify integrity" / game repair restores the original file; just
  re-run the installer afterwards.
- Restart the game for the change to take effect.

## Troubleshooting

- "Python 3 was not found": install Python from python.org (tick *Add
  python.exe to PATH*) and run `Install.bat` again.
- "DataPC.forge not found": pass the path as shown above.

## Credits

- **Kamzik123** — [AnvilToolkit](https://www.nexusmods.com/assassinscreed/mods/30),
  the community toolkit for AnvilNext `.forge` packages.
- The installer is built from scratch and uses the game's own `lzo.dll`.
