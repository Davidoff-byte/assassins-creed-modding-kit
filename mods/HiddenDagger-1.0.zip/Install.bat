@echo off
setlocal
title Hidden Dagger - installer

echo ============================================
echo   Assassin's Creed Rogue - Hidden Dagger
echo ============================================
echo.
echo Close the game before continuing (it locks the game files).
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo Python 3 was not found. Install it from https://www.python.org/downloads/
    echo ^(tick "Add python.exe to PATH" during install^), then run this again.
    pause
    exit /b 1
)

python "%~dp0hide_dagger.py" %*
echo.
pause
