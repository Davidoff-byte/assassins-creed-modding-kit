#!/usr/bin/env python3
"""Hide Shay's off-hand dagger in Assassin's Creed Rogue.

Makes every sword+dagger set read as a single sword by setting the off-hand
weapon entity's visibility flags (IsVisible=False, IsHidden=True) in the game's
own DataPC.forge.  No game files are shipped or redistributed: this only edits
the copy you already own.

Usage:
    python hide_dagger.py [path\\to\\DataPC.forge]
    (no argument -> the default Steam library path is used)
"""
import ctypes
import os
import shutil
import struct
import sys
import zlib
from pathlib import Path

MAGIC = 0x1004FA9957FBAA33
BS = 32768
PATTERN = bytes([0, 1, 1, 1, 1, 0, 1, 0])  # IsSpawned..IsMediumObject bool run

DEFAULT_FORGE = Path(r"D:\SteamLibrary\steamapps\common\Assassin's Creed Rogue\DataPC.forge")
GAME_DIRS = [
    Path(r"D:\SteamLibrary\steamapps\common\Assassin's Creed Rogue"),
    Path(r"C:\Program Files (x86)\Steam\steamapps\common\Assassin's Creed Rogue"),
    Path(r"C:\Program Files\Steam\steamapps\common\Assassin's Creed Rogue"),
]


# ---------------------------------------------------------------- LZO
class Lzo:
    def __init__(self, path):
        self.dll = ctypes.WinDLL(str(path))
        self.dec = self.dll.lzo1x_decompress_safe
        self.dec.restype = ctypes.c_int
        self.dec.argtypes = [ctypes.c_char_p, ctypes.c_size_t, ctypes.c_char_p,
                             ctypes.POINTER(ctypes.c_size_t), ctypes.c_void_p]
        self._comp = None

    def decompress(self, src, out_len):
        dst = ctypes.create_string_buffer(out_len)
        n = ctypes.c_size_t(out_len)
        rc = self.dec(src, len(src), dst, ctypes.byref(n), None)
        if rc != 0:
            raise RuntimeError(f"lzo decompress rc={rc}")
        return dst.raw[:n.value]

    def compress(self, src):
        if self._comp is None:
            f = self.dll.lzo1x_1_compress
            f.restype = ctypes.c_int
            f.argtypes = [ctypes.c_char_p, ctypes.c_size_t, ctypes.c_char_p,
                          ctypes.POINTER(ctypes.c_size_t), ctypes.c_void_p]
            self._comp = f
            self._work = ctypes.create_string_buffer(1 << 18)
        dst = ctypes.create_string_buffer(len(src) + len(src) // 8 + 128 + 3)
        n = ctypes.c_size_t(len(dst))
        rc = self._comp(src, len(src), dst, ctypes.byref(n), self._work)
        if rc != 0:
            raise RuntimeError(f"lzo compress rc={rc}")
        return dst.raw[:n.value]


_lzo = None


def find_lzo(game_dir):
    for c in [game_dir / "libs" / "lzo.dll", game_dir / "lzo.dll"]:
        if c.is_file():
            return c
    raise FileNotFoundError("lzo.dll not found in the game folder")


def lzo(game_dir):
    global _lzo
    if _lzo is None:
        _lzo = Lzo(find_lzo(game_dir))
    return _lzo


# ---------------------------------------------------------------- forge
class Reader:
    def __init__(self, d):
        self.d, self.p = d, 0
    def i32(self):
        v = struct.unpack_from("<i", self.d, self.p)[0]; self.p += 4; return v
    def i64(self):
        v = struct.unpack_from("<q", self.d, self.p)[0]; self.p += 8; return v
    def u64(self):
        v = struct.unpack_from("<Q", self.d, self.p)[0]; self.p += 8; return v
    def u16(self):
        v = struct.unpack_from("<H", self.d, self.p)[0]; self.p += 2; return v
    def cstr(self, n):
        b = self.d[self.p:self.p + n]; self.p += n
        return b.split(b"\x00", 1)[0].decode("latin1")


def parse_forge(data):
    r = Reader(data)
    assert r.cstr(9) == "scimitar", "not a DataPC.forge"
    r.i32()
    header = r.i64()
    r.p = header
    r.i32(); r.i32()
    r.p += 12
    r.i32(); r.i32(); r.i32()
    r.i32()
    first = r.i64()
    entries = []
    off = first
    while off > 0:
        r.p = off
        files = r.i32(); r.i32(); r.u64()
        nxt = r.i64(); r.i32(); r.i32()
        name_off = r.u64(); r.u64()
        recs = []
        for _ in range(files):
            desc_off = r.p
            o = r.i64(); r.u64(); sz = r.i32()
            recs.append((o, sz, desc_off))
        names = []
        r.p = name_off
        for _ in range(files):
            rec0 = r.p
            r.i32(); r.i32(); r.i32(); r.i32(); r.u64()
            r.i32(); r.i32(); r.i32(); r.i32()
            r.i32()
            name = r.cstr(0x80)
            r.u64(); r.u64(); r.i32()
            names.append((name, rec0))
        for i in range(files):
            o, sz, desc_off = recs[i]
            name, name_rec_off = names[i]
            entries.append({"offset": o, "size": sz, "name": name,
                            "desc_off": desc_off, "name_rec_off": name_rec_off})
        off = nxt if nxt > 0 else 0
    return entries


# ---------------------------------------------------------------- container
def parse_cfd(b, off):
    assert struct.unpack_from("<Q", b, off)[0] == MAGIC
    o = off + 8
    ver = struct.unpack_from("<h", b, o)[0]; o += 2
    algo = b[o]; o += 1
    bi = struct.unpack_from("<I", b, o)[0]; o += 4
    n = struct.unpack_from("<H", b, o)[0]; o += 2
    infos = [struct.unpack_from("<HH", b, o + 4 * i) for i in range(n)]
    o += 4 * n
    blocks = []
    for un, cn in infos:
        ad = struct.unpack_from("<I", b, o)[0]; o += 4
        data = b[o:o + cn]; o += cn
        blocks.append({"un": un, "cn": cn, "ad": ad, "data": data})
    return o, {"ver": ver, "algo": algo, "bi": bi, "blocks": blocks}


def write_cfd(hdr, blocks):
    out = bytearray()
    out += struct.pack("<Q", MAGIC) + struct.pack("<h", hdr["ver"])
    out += bytes([hdr["algo"]]) + struct.pack("<I", hdr["bi"])
    out += struct.pack("<H", len(blocks))
    for blk in blocks:
        out += struct.pack("<HH", blk["un"], blk["cn"])
    for blk in blocks:
        out += struct.pack("<I", blk["ad"]) + blk["data"]
    return bytes(out)


def load_container(b):
    fts = struct.unpack_from("<i", b, 0)[0]
    ft = b[4:4 + fts]
    o, meta = parse_cfd(b, 4 + fts)
    o, files = parse_cfd(b, o)
    return {"fts": fts, "ft": ft, "meta": meta, "files": files}


def save_container(c):
    out = bytearray(struct.pack("<i", c["fts"]) + c["ft"])
    out += write_cfd(c["meta"], c["meta"]["blocks"])
    out += write_cfd(c["files"], c["files"]["blocks"])
    return bytes(out)


def decompress_all(game_dir, blocks):
    out = bytearray()
    for blk in blocks:
        out += blk["data"] if blk["un"] == blk["cn"] else lzo(game_dir).decompress(blk["data"], blk["un"])
    return bytes(out)


def patch_container(game_dir, blob):
    c = load_container(blob)
    files = bytearray(decompress_all(game_dir, c["files"]["blocks"]))
    i = files.find(PATTERN)
    if i == -1 or i > 0x2000:
        return None
    files[i + 1] = 0   # IsVisible = False
    files[i + 5] = 1   # IsHidden  = True
    changed = i // BS
    nb = []
    for bi, blk in enumerate(c["files"]["blocks"]):
        chunk = bytes(files[bi * BS:bi * BS + blk["un"]])
        if bi == changed:
            comp = lzo(game_dir).compress(chunk)
            use = comp if len(comp) < len(chunk) else chunk
            nb.append({"un": len(chunk), "cn": len(use), "ad": 0, "data": use})
        else:
            nb.append(dict(blk))
    for blk in nb:
        blk["ad"] = zlib.adler32(blk["data"], 0) & 0xffffffff
    c["files"]["blocks"] = nb
    return save_container(c)


def locate():
    if len(sys.argv) > 1:
        return Path(sys.argv[1]), Path(sys.argv[1]).parent
    if DEFAULT_FORGE.is_file():
        return DEFAULT_FORGE, DEFAULT_FORGE.parent
    for d in GAME_DIRS:
        if (d / "DataPC.forge").is_file():
            return d / "DataPC.forge", d
    raise FileNotFoundError("DataPC.forge not found - pass the path as an argument")


def main():
    forge, game_dir = locate()
    print(f"forge: {forge}")
    print(f"game : {game_dir}")
    backup = forge.with_suffix(".forge.bak_dagger")
    if not backup.exists():
        print(f"backing up -> {backup}")
        shutil.copy2(forge, backup)
    else:
        print(f"backup already exists: {backup}")

    entries = parse_forge(forge.read_bytes())
    buf = bytearray(forge.read_bytes())
    inplace = appended = skipped = done = 0
    for e in entries:
        if not e["name"].endswith("_Secondary"):
            continue
        blob = bytes(buf[e["offset"]:e["offset"] + e["size"]])
        new = patch_container(game_dir, blob)
        if new is None:
            skipped += 1
            continue
        if len(new) <= e["size"]:
            buf[e["offset"]:e["offset"] + len(new)] = new
            struct.pack_into("<i", buf, e["desc_off"] + 16, len(new))
            struct.pack_into("<i", buf, e["name_rec_off"], len(new))
            inplace += 1
        else:
            off = (len(buf) + 0x7FFF) & ~0x7FFF
            buf += b"\x00" * (off - len(buf))
            buf += new
            struct.pack_into("<q", buf, e["desc_off"], off)
            struct.pack_into("<i", buf, e["desc_off"] + 16, len(new))
            struct.pack_into("<i", buf, e["name_rec_off"], len(new))
            appended += 1
        done += 1
    forge.write_bytes(bytes(buf))
    print(f"DONE: {done} sword sets patched ({inplace} in place, {appended} appended), "
          f"{skipped} skipped")
    print("Launch the game (restart if it was running) - the off-hand dagger will be gone.")
    print(f"To undo: restore {backup.name} over DataPC.forge.")


if __name__ == "__main__":
    main()
