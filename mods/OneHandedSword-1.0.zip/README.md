# One-Handed Sword — Assassin's Creed Rogue

**Short description:** Shay fights with a one-handed sword moveset.

In AC Rogue the player's weapon class is "sword and dagger", which uses the
dual-wield animations. This mod remaps that fight type to single-sword, so the
same equipped weapon is used with the one-handed moveset — attacks, counters
and finishers.

Version 1.0.

## Features

- One-handed sword moveset for the player.
- Toggle in the INI (`OneHandedSword=true/false`) — no reinstall needed.
- Ships the base AC.PatchFix display features: ultrawide/aspect-ratio support,
  FOV correction, FPS unlock, full display-mode list, UI scaling, language
  unlock. These are upstream (see Credits); the one-handed remap is the change.

## Requirements

- Assassin's Creed Rogue (PC).
- An ASI loader — **Ultimate ASI Loader** (`dinput8.dll`) placed in the game
  folder. Not included.
- The game **closed** while installing.

Tested on the current Steam build (`ACC.exe` MD5
`a323729f3799a808c8148b695e1e23b8`).

## Install

1. Quit Rogue.
2. Make sure an ASI loader (`dinput8.dll`) is in the game folder.
3. Copy the `plugins` folder into your game folder (merge with an existing
   `plugins` folder). You should end up with:
   - `<game>\plugins\AC.Rogue.PatchFix.asi`
   - `<game>\plugins\AC.Rogue.PatchFix.ini`
4. Launch the game. Shay now fights one-handed.

## Uninstall

Delete `<game>\plugins\AC.Rogue.PatchFix.asi` and
`<game>\plugins\AC.Rogue.PatchFix.ini`.

## Configuration

Edit `<game>\plugins\AC.Rogue.PatchFix.ini`:

- `[Gameplay] OneHandedSword = true` — the moveset remap. Set `false` for the
  original dual-wield animations.

The same file also holds the upstream display settings.

## Notes

- Single-player only.
- Only touches the plugin; game data is not modified.
- If you already run AC.PatchFix, back up its `.asi` first — this release
  redistributes a modified build of it under the same file name and does not
  include the coop/combat hooks.
- Companion mod: **Hidden Dagger** — hides the off-hand dagger so the set
  reads as a true single sword.

## Troubleshooting

- No effect: confirm the ASI loader is present and the game was restarted.
- Log: `<game>\plugins\AC.Rogue.PatchFix.log`.

## Credits

- Base framework and display features: **AC.PatchFix** by PlayDay
  (<https://github.com/playday3008/AC.PatchFix>), MIT. This build is a
  modified redistribution of it; the one-handed-sword remap is the addition.
- ASI loader: **Ultimate ASI Loader** by ThirteenAG
  (<https://github.com/ThirteenAG/Ultimate-ASI-Loader>), not included.

## License

The bundled `.asi` is a modified AC.PatchFix build and is covered by its MIT
license (see `LICENSE.txt`). The added changes are provided as-is.
